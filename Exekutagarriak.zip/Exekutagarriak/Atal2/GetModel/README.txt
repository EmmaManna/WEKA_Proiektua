Parametro optimoak emanda, eredu iragarlea (Multilayer Perceptron) eta bere kalitatearen estimazioa lortu.
Hiru ebaluazio eskema erabiliko dira ez-zintzoa, 10 fold Cross Validation, 100 Hold-Out (70%-30%). 

Aurrebaldintzak:

1- Lehenengo parametro bezala train.arff fitxategia.
2- Bigarren parametro bezala eredu iragarlearen .model fitxategia gordetzeko path-a.
3- Hirugarren parametro bezala kalitatearen estimazioa gordetzeko .txt fitxategiaren path-a.
4- Laugarren parametro bezala parametro egokiak gordetzen dituen .txt fitxategiaren path-a.

Post baldintza:

1- Bigarren parametroan adierazitako helbidean modeloa serializatuko da (.model).
2- Hirugarren parametroan adierazitako helbidean sortutako .txt fitxategia gordeko da.

Argumentuen zerrenda eta deskribapena:

1- Sarrerako train.arff fitxategiaren helbidea.
2- Irteerako eredu iragalearen MultiLayerPerceptron.model fitxategiaren helbidea.
3- Irteerako .txt fitxategiaren helbidea.
4- Parametro egokiak gordeta dituen .txt fitxategiaren path-a.

Erabilera adibidea komando-lerroan:

java -jar GetModel.jar <train.arff> <MultiLayerPerceptron.model> <MPKalitateEstimazioa.txt> <optimalParameters.txt>


* @author Xabi Dermit, Jon Gondra eta Emma Manna *

