FSS software paketean, alde batetik, entrenamendu multzoko atributuak hautatu eta beste
aldetik, ebaluazio multzoa entrenamenduarekiko bateragarria egiteko baliabideak emango dira.
AttributeSelection aplikatu eta hiztegi bateragarria lortzen da ere.
     
Aurrebaldintzak:

1- Lehenengo parametro bezala train.arff fitxategia.
2- Bigarren parametro bezala test.arff fitxategia.
3- Zein errepresentzaio bektorial nahi den BoW edo TF·IDF.
4- Laugarren parametro bezala Sparse edo NonSparse emaitza fitxategi bezala nahi dugun.
5- Bostgarren parametro bezala train egokituta fitxategiaren path-a.
6- Seigarren parametro bezala test egokituta fitxategiaren path-a.

Post baldintzak:

1- Hirugarren eta laugarren parametroetan adierazitako helbidean sortutako .arff fitxategiak gordeko dira.

Argumentuen zerrenda eta deskribapena:

1- Sarrerako train.arff fitxategiaren helbidea.
2- Sarrerako dev.arff fitxategiaren helbidea.
3- Parametroa - BoW = 0 | TF·IDF = 1
4- Parametroa - Sparse = yes | NonSparse = no
5- Irteerako egokitutako train fitxategiaren helbidea.
6- Irteerako egokitutako dev fitxategiaren helbidea.

Erabilera adibidea komando-lerroan:

java -jar FSS.jar <train.arff> <test.arff> 0 yes <trainFSS.arf> <testFSS.arff>


* @author Xabi Dermit, Jon Gondra eta Emma Manna *