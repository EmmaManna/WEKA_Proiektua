ParamOptimization ereduaren parametro optimoak ekortuko ditu. 
Ekortutako parametroak Hidden Layers eta Learning Rate izango dira.
Klase minoritarioarekiko f-measure erabiliz aukeratuko da hoberena.

Aurrebaldintzak:

1- Lehenengo parametro bezala entrenamendurako erabiliko den train.arff fitxategiaren helbidea.
2- Bigarren parametro bezala lortu diren parametro optimoak gordetzeko .txt fitxategiaren helbidea.

Post baldintza:

1- Lortu diren parametro optimoak gordetzeko .txt fitxategiaren helbidea.

Argumentuen zerrenda eta deskribapena:

1- Entrenamendurako .arff fitxategiaren helbidea.
2- Parametro optimoak gordetzeko .txt fitxategiaren helbidea.

Erabilera adibidea komando-lerroan:

java -jar ParamOptimization.jar <train.arff> <outPath>

* @author Xabi Dermit, Jon Gondra eta Emma Manna *