GetBaselineModel baseline sortu (logisticRegression.model) eta beronen kalitatearen
estimazioa gorde (kalitatea.txt). Hiru ebaluazio eskema erabiliko dira ez-zintzoa, 
10 fold Cross Validation, 100 Hold-Out (70%-30%). 

Aurrebaldintzak:

1- Lehenengo parametro bezala train.arff fitxategia.
2- Bigarren parametro bezala eredu iragarlearen .model fitxategia gordetzeko path-a.
3- Hirugarren parametro bezala kalitatearen estimazioa gordetzeko .txt fitxategiaren path-a.

Post baldintzak:

1- Bigarren parametroan adierazitako helbidean modeloa serializatuko da (.model).
2- Hirugarren parametroan adierazitako helbidean sortutako .txt fitxategia gordeko da.

Argumentuen zerrenda eta deskribapena:

1) Sarrerako train.arff fitxategiaren helbidea.
2) Irteerako eredu iragalearen .model fitxategiaren helbidea.
3) Irteerako .txt fitxategiaren helbidea.

Erabilera adibidea komando-lerroan:

java -jar GetBaselineModeal.jar <train.arff> <baseline.model> <kalitaterenEstimazioa.txt> 


* @author Xabi Dermit, Jon Gondra eta Emma Manna *