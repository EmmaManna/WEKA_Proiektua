Predictions paketearen helburua dokumentu bat (ala sorta bat) sailkatzea da
emandako eredu iragarle baten bitartez (adb. LogisticRegression.model edo MultilayerPerceptron.model).

Aurrebaldintzak:

1- Lehenengo parametro bezala test.arff fitxategia.
2- Bigarren parametro bezala eredu iragarlearen .model fitxategia.
3- Hirugarren parametro bezala iragarpenak gordetzeko .txt fitxategiaren path-a.

Post baldintza:

1- Hirugarren parametroan adierazitako helbidean sortutako .txt fitxategia gordeko da.

Argumentuen zerrenda eta deskribapena:

1- Sarrerako test.arff fitxategiaren helbidea.
2- Sarrerako eredu iragalearen .model fitxategiaren helbidea.
3- Irteerako .txt fitxategiaren helbidea.

Erabilera adibidea komando-lerroan:

java -jar Predictions.jar <test.arff> <baseline.model> <TestPredictionsBaseline.txt>


* @author Xabi Dermit, Jon Gondra eta Emma Manna *