TransformRaw atributu espazioa erreprezentazio bektorial batera transformatzeko
softwarea. Aukera ezberdinak kontsideratzeko malgutasuna izatea probesten da
(adb. BoW ala TF·IDF errepresentazioa). Parametro bezala ematen den .arff fitxategiaren 
atributu espazioa errepresentazio bektorial batera aldatu (BoW edo TF·IDF eta Sparse edo NonSparse).
    
Aurrebaldintzak:

1- Lehenengo parametro bezala .arff fitxategia.
2- Zein errepresentzaio bektorial nahi den BoW edo TF·IDF.
3- Hirugarren parametro bezala Sparse edo NonSparse emaitza fitxategi bezala nahi dugun.
4- Sortutako .arff fitxategiaren path-a.

Post baldintza:

1- Laugarren parametroan adierazitako helbidean sortutako arff fitxategia gordeko da.

Argumentuen zerrenda eta deskribapena:

1) Sarrerako .arff fitxategiaren helbidea.
2) Parametroa - BoW = 0 | TF·IDF = 1
3) Parametroa - Sparse = yes | NonSparse = no
4) Irteerako .arff fitxategiaren helbidea.

Erabilera adibidea komando-lerroan:

java -jar TransformRaw.jar <train.arff> 1 yes <outputPath>


 * @author Xabi Dermit, Jon Gondra eta Emma Manna *