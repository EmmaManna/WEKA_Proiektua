MakeCompatible ebaluazio multzo bat (adb. dev.arff), entrenamendu multzoak
ezarritako espazioan errepresentatzeko errutina da (BoW nahiz TF·IDF eta Sparse
nahiz NonSparse). Parametro bezala ematen den .arff fitxategia egokitu eta 
atributu espazioa errepresentazio bektorial batera aldatuko du (BoW edo TF·IDF).
Ebaluazio multzoaren aldaketak bermatuko ditu (adb. Headers-ak
train multzoarekin berdindu). Atributu espazioaren hiztegia gordeko da.
     
Aurrebaldintzak:

1- Lehenengo parametro bezala train.arff fitxategia.
2- Bigarren parametro bezala test.arff fitxategia.
3- Zein errepresentzaio bektorial nahi den BoW edo TF·IDF.
4- Laugarren parametro bezala Sparse edo NonSparse emaitza fitxategi bezala nahi dugun.
5- Sortutako .arff fitxategia gordetzeko path-a.

Post baldintza:

1- Bostgarren parametroan adierazitako helbidean sortutako .arff fitxategia gordeko da.

Argumentuen zerrenda eta deskribapena:

1) Sarrerako train.arff fitxategiaren helbidea.
2) Sarrerako test.arff fitxategiaren helbidea.
3) Parametroa - BoW = 0 | TF·IDF = 1
4) Parametroa - Sparse = yes | NonSparse = no
5) Irteerako .arff fitxategiaren helbidea.

Erabilera adibidea komando-lerroan:

java -jar MakeCompatible.jar <train.arff> <test.arff> 1 yes <outputPath> 
           

* @author Xabi Dermit, Jon Gondra eta Emma Manna *