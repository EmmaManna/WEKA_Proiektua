GetRaw dokumentu  sorta  arff  raw  formatora  bihurtzeko  ad-hoc  diseinatutako  softwarea.
Dokumentu bakoitza instantzia bat izango da.  Hau text deritzan string motako atributu bakar
batekin karakterizatuko da eta class deritzan klase nominalarekin (adb.  yes, no).
Datu gordinak CSV formatuan sartuko dira, train eta test desberdinduko dira eta bakoitzari
berhar dituzten eraldaketan egingo zaizkie eta .arff formatura bihurtuko ditu.
 
Aurrebaldintzak:

1- Lehenengo parametro bezala train edo test multzoa den adieraziko da.
2- Bigarren parametro bezala existitzen den .csv fitxategiaren helbidea pasatzea.
3- Hirugarren parametro bezala .arff fitxategia gorde nahi den helbidea existitzea.
4- Datu sortaren atributuen ordena: (1)identifikatzailea, (2)Klasea, (3)Textua.

Post baldintza:

1- Bigarren parametroan adierazitako helbidean sortutako .arff fitxategia gorde da.

Argumentuen zerrenda eta deskribapena:

1) Fitxategia train edo test den adierazi idatziz: {train,test}
2) .csv fitxategiaren helbidea.
3) .arff fitxategia gordeko den helbidea.

Erabilera adibidea komando-lerroan:

java -jar getRaw.jar <train/test> <input.csv> <outputPath>


* @author Xabi Dermit, Jon Gondra eta Emma Manna *